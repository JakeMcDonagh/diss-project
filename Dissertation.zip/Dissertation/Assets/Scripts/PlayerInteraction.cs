﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/*
 * This class focuses on managing all of the different interactions that can take place between players, their pieces, the tiles on the board as well as the main game loop.
 * 
 */

public class PlayerInteraction : MonoBehaviour {
    // Class variables which are used in order determine the current state of the game.
    private Boolean hasLooped = false;
    private Boolean isPlayer1Turn = true;

    private Color darkRed = new Color32(94, 10, 10, 255);
    private Color darkBlue = new Color32(16, 47, 96, 255);

    // Important variable used to store informaiton about the previous gameobject clicked. Used in order to make comparisons between this object and the next gameobject.
    public static GameObject boardPiece;

    // Iniitalizes the scene so that Player 1 always goes first.
    void Start () {
        object[] player2Pieces = GameObject.FindGameObjectsWithTag("Player_Piece");

        foreach (GameObject piece in player2Pieces)
        {
            if(piece.GetComponent<Properties>().belongsTo == "Player2")
            {
                piece.GetComponent<Renderer>().material.color = darkBlue;
            }
        }


    }

   
	
	// Update is called once per frame
	void Update () {
       

    }

    // This function is called whenever the user clicks on the scene. The function uses Case-switch statements to determine what type of object was clicked.
    private void OnMouseUp()
    { 
        Properties properties = gameObject.GetComponent<Properties>();
        object[] tiles = GameObject.FindGameObjectsWithTag("Tile");



    // TODO: Make check to see if mouse is over UI element. If so, ignore click

    // The Case-switch statement used in order to determine what type of gameobject was clicked. Uses the description property in order to determine the type of gameobject.
        switch (properties.description)
        {
            case "Cube":
                foreach (GameObject t in tiles)
                {
                    // Iniitally checks to see if the player is already making a move.
                    if (t.GetComponent<Renderer>().material.color == Color.green)
                    {
                        // If the player is trying go move their piece onto a piece that belongs to them, the action is cancelled. Otherwise the piece moves to it's location and the enemy piece is destroyed.
                        if (boardPiece.GetComponent<Properties>().belongsTo == gameObject.GetComponent<Properties>().belongsTo)
                        {
                            return;
                        }
                        else
                        {
                            manageMovement(gameObject, tiles);
                            Destroy(gameObject);
            
                            foreach (GameObject tile in tiles)
                            {
                                tile.GetComponent<Renderer>().material = tile.GetComponent<Properties>().colour;
                            }
                            return;
                        }
                    }
                }

                // Checks to see if the piece belongs to the enemy or if the player has already moved with the piece. If so, the user isn't able to interact with the piece.
                // Otherwise the game will highlight the available moves with said piece.
                if (gameObject.GetComponent<Renderer>().material.color == darkRed)
                {
                    return;
                } else if (gameObject.GetComponent<Renderer>().material.color == darkBlue)
                {
                    return;
                } else

                {
                    TileManagement tile = properties.CurrentTile;
   
                    highlightMovement(tile);
                    boardPiece = gameObject;
                } 
                break;
            // If a tile is clicked and the current available moves are highlighted, then move the selected piece to the tile selected.
            case "Tile":
                object[] Pieces = GameObject.FindGameObjectsWithTag("Player_Piece");

                foreach (GameObject piece in Pieces)
                {
                    if (properties.name == piece.GetComponent<Properties>().CurrentTile.name)
                    {
                        return;
                    }
                }

                if (gameObject.GetComponent<Renderer>().material.color == Color.green)
                {
                    manageMovement(gameObject, tiles);

                } else
                {
                    Debug.Log("This is not a player piece");
                }
                break;
            default:
                Debug.Log("ERROR");
                break;


        }

    }

    // The highlightMovement function displays the current available moves to the user when they select an object. The method is called recursively up to 2 times to allow for piece to
    // move cardinally up to 2 spaces.
    private void highlightMovement(TileManagement tile)
    {
       
        TileManagement[] adjacentTiles = tile.GetComponent<TileManagement>().AdjacentTiles;
        tile.GetComponent<Renderer>().material.color = Color.green;

        foreach (TileManagement adjacentTile in adjacentTiles)
        {
            if (adjacentTile == null)
            {
                break;
            }
            else if (hasLooped == false)
            {
                

                adjacentTile.GetComponent<Renderer>().material.color = Color.green;
                hasLooped = true;
                highlightMovement(adjacentTile);

            }
            else if (hasLooped == true)
            {
            

                adjacentTile.GetComponent<Renderer>().material.color = Color.green;
            }         
        }
        hasLooped = false;
    }

    // The manageMovement function uses a manhattan distance equation in order to find the delta x/y values to allow the piece to move to it's correct position.
    // The piece then darkens to signify that the piece has moved and can not be interacted with any further.
    private void manageMovement(GameObject piece, object[] tiles)
    {
        float DeltaX = (piece.GetComponent<Properties>().transform.position.x) - (boardPiece.transform.position.x);
        float DeltaZ = (piece.GetComponent<Properties>().transform.position.z) - (boardPiece.transform.position.z);

        boardPiece.GetComponent<Properties>().CurrentTile = piece.GetComponent<Properties>().CurrentTile;
        boardPiece.transform.Translate(DeltaX, 0, DeltaZ);

        if (boardPiece.GetComponent<Properties>().belongsTo == "Player1")
        {
            boardPiece.GetComponent<Renderer>().material.color = darkRed;
        }
        else
        {
            boardPiece.GetComponent<Renderer>().material.color = darkBlue;
        }


        foreach (GameObject t in tiles)
        {
            t.GetComponent<Renderer>().material = t.GetComponent<Properties>().colour;
        }

    }
  
    // This function ends the current player turn and starts the opposing player turn.
    public void EndTurn()
    {
        Debug.Log("Player turn has ended");

        if (isPlayer1Turn == true)
        {
            isPlayer1Turn = false;
        }
        else
        {
            isPlayer1Turn = true;
        }

         manageColours();
    }

    // The manageColours function manages the different colours used within the game to signify active and inactive pieces. This may change when models are introduced at a later point.
    public void manageColours()
    {
        object[] pieces = GameObject.FindGameObjectsWithTag("Player_Piece");



        foreach (GameObject piece in pieces)
        {
            piece.GetComponent<Renderer>().material = piece.GetComponent<Properties>().colour;

            if (piece.GetComponent<Properties>().belongsTo == "Player2" && isPlayer1Turn == true)
            {
                piece.GetComponent<Renderer>().material.color = darkBlue;
            }
            else if (piece.GetComponent<Properties>().belongsTo == "Player1" && isPlayer1Turn == false)
            {
                piece.GetComponent<Renderer>().material.color = darkRed;
            }
        }
    }
}

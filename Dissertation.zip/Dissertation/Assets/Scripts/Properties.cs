﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Properties : MonoBehaviour {
    public Boolean isPlayerPiece;
    public String description;
    public TileManagement CurrentTile;
    public String belongsTo;
    public Material colour;
    public Material acivatedColour;


    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}

﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TileManagement : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}

    public TileManagement[] AdjacentTiles;
	
	// Update is called once per frame
	void Update () {
		
	}

    internal object GetComponentInChildren(object cube)
    {
        throw new NotImplementedException();
    }
}

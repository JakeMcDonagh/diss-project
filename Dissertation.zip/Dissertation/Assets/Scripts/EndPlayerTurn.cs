﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EndPlayerTurn : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {

		
	}

    // Called to end current players turn and to start the next player turn upon clicking the button
    public void EndTurn ()
    {
        Debug.Log("Player turn has ended");
        

    }
}

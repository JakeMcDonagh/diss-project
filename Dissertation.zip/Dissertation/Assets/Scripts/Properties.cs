﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/*
 * THe properties that each GameObject is capable of having. Please note that not every gamebobject in a given scene needs to have
 * all the variables used as a requirement. 
 */

public class Properties : MonoBehaviour {
    public Boolean isPlayerPiece;
    public String description;
    public TileManagement CurrentTile;
    public String belongsTo;
    public Material colour;


    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}

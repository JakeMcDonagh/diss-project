﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerInteraction : MonoBehaviour {
    private Boolean hasLooped = false;
    private Boolean isPlayer1Turn = true;

    public static GameObject boardPiece;

    // Use this for initialization
    void Start () {
		
	}

   
	
	// Update is called once per frame
	void Update () {
       

    }

    private void OnMouseUp()
    { 
        Properties properties = gameObject.GetComponent<Properties>();
        object[] tiles = GameObject.FindGameObjectsWithTag("Tile");



        // TODO: Make check to see if mouse is over UI element. If so, ignore click


        switch (properties.description)
        {
            case "Cube":
                TileManagement tile = properties.CurrentTile;

                foreach (GameObject t in tiles)
                {
                    if (t.GetComponent<Renderer>().material.color == Color.green)
                    {
                        return;
                    }
                }

                highlightMovement(tile);
                boardPiece = gameObject;
                break;
            case "Tile":
                if (gameObject.GetComponent<Renderer>().material.color == Color.green)
                {
                    float DeltaX = (properties.transform.position.x) - (boardPiece.transform.position.x);
                    float DeltaZ = (properties.transform.position.z) - (boardPiece.transform.position.z);

                    boardPiece.GetComponent<Properties>().CurrentTile = properties.CurrentTile;
                    boardPiece.transform.Translate(DeltaX, 0, DeltaZ);



                    foreach (GameObject t in tiles)
                    {
                        t.GetComponent<Renderer>().material = t.GetComponent<Properties>().colour;
                    }

                } else
                {
                    Debug.Log("This is not a player piece");
                }
                break;
            default:
                Debug.Log("ERROR");
                break;


        }

        //boardPiece = gameObject;
    }


    private void highlightMovement(TileManagement tile)
    {
       
        TileManagement[] adjacentTiles = tile.GetComponent<TileManagement>().AdjacentTiles;
       

       // Debug.Log("The cube is currently on " + tile);
        tile.GetComponent<Renderer>().material.color = Color.green;

        // Debug.Log("The adjacent tiles are:" + adjacentTiles);

        foreach (TileManagement adjacentTile in adjacentTiles)
        {
            if (adjacentTile == null)
            {
                break;
            }
            else if (hasLooped == false)
            {
                

                adjacentTile.GetComponent<Renderer>().material.color = Color.green;
                hasLooped = true;
                highlightMovement(adjacentTile);

            }
            else if (hasLooped == true)
            {
            

                adjacentTile.GetComponent<Renderer>().material.color = Color.green;
            }         
        }
        hasLooped = false;
    }

    public void EndTurn()
    {
        Debug.Log("Player turn has ended");

        if (isPlayer1Turn == true)
        {
            isPlayer1Turn = false;
        }
        else
        {
            isPlayer1Turn = true;
        }

        manageColours();
    }

    public void manageColours()
    {
        object[] pieces = GameObject.FindGameObjectsWithTag("Player_Piece");



        foreach (GameObject piece in pieces)
        {
            piece.GetComponent<Renderer>().material = piece.GetComponent<Properties>().colour;

            if (piece.GetComponent<Properties>().belongsTo == "Player2" && isPlayer1Turn == true)
            {
                piece.GetComponent<Renderer>().material = piece.GetComponent<Properties>().acivatedColour;
            }
            else if (piece.GetComponent<Properties>().belongsTo == "Player1" && isPlayer1Turn == false)
            {
                piece.GetComponent<Renderer>().material = piece.GetComponent<Properties>().acivatedColour;
            }
        }
    }
}
